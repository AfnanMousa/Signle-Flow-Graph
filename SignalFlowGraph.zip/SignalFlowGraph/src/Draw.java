import javax.swing.JPanel;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.QuadCurve2D;
import java.util.LinkedList;
import java.util.Random;

public class Draw extends JPanel {
    LinkedList<Integer> Points=new LinkedList<>();
    int initialPoint;
    /**
     * Create the panel.
     */
    public Draw() {

        //paint( g);
    }
    @Override
    public void paintComponent(Graphics g) {

        super.paintComponent(g);
        initialPoint = 1164 / GUIDraw.NumberNode;
        int sum=(initialPoint/4);
        for (int i = 0; i < GUIDraw.NumberNode; i++) {
            g.setColor(Color.darkGray);

            g.fillOval(sum, 150, (initialPoint/4), (initialPoint/4));
            System.out.println("point "+sum+" "+(initialPoint/4)+" "+(initialPoint/4));
            g.setColor(Color.red);
            g.drawString("Node "+(i+1),sum ,150 +(initialPoint/3) );
            Points.add(sum);
            sum+=initialPoint;
        }
        g.setColor(Color.darkGray);
        doDrawing(g);
    }
    private void doDrawing(Graphics g) {

        Graphics2D g2d = (Graphics2D) g;
        String[][] array=GUIDraw.Basic;
        QuadCurve2D q=new QuadCurve2D.Double();
        RenderingHints rh = new RenderingHints(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        rh.put(RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY);

        g2d.setRenderingHints(rh);
        Random r=new Random();
        float strokewidth = r.nextFloat()*50+10;
        BasicStroke bas=new BasicStroke(strokewidth);

        for(int i=1;i<array.length;i++){
            for(int j=1;j<array.length;j++){
                if(array[i][j]!=null){
                    //q.setCurve(((Points.get(j-1))+(initialPoint/8)+1),150,(Math.abs(Points.get(i-1)-Points.get(j-1)))/2,(Math.abs(Points.get(i-1)-Points.get(j-1))),((Points.get(i-1))+(initialPoint/8)),150);
                     if(Points.get(i-1)==Points.get(j-1)){

                         g.drawOval(((Points.get(i-1))+(initialPoint/8)),(150+((Points.get(i-1)-Points.get(j-1)))/8),75,75);
//                        g.drawArc(((Points.get(i-1))+(initialPoint/8)),(500+((Points.get(i-1)-Points.get(j-1)))/8),(Points.get(j-1)-Points.get(i-1)),(Points.get(j-1)-Points.get(i-1)),0,180);
                        // System.out.println(j+" "+i+"Arc "+Math.abs((Points.get(j-1))+(initialPoint/8))+" "+Math.abs(150)+" "+Math.abs(Points.get(i-1)-Points.get(j-1))+" "+Math.abs(Points.get(i-1)-Points.get(j-1)));
                        g.setColor(Color.red);
                        if(array[i][j].equals("-")){
                            g.drawString("-1",(((Points.get(j-1))+(initialPoint/8))+((Points.get(i-1)-Points.get(j-1)))/2) ,(150+((Points.get(j-1)-Points.get(i-1)))/8) );
                        }
                        else {
                            g.drawString(array[i][j],(((Points.get(j-1))+(initialPoint/8))+((Points.get(i-1)-Points.get(j-1)))/2) ,(150+((Points.get(j-1)-Points.get(i-1)))/8) );
                        }
                        g.setColor(Color.darkGray);

                    }
                    else if(Points.get(i-1)>Points.get(j-1)){
                        g.drawArc(((Points.get(j-1))+(initialPoint/8)),(150-((Points.get(i-1)-Points.get(j-1)))/8),(Points.get(i-1)-Points.get(j-1)),(Points.get(i-1)-Points.get(j-1))/4,0,180);
                        // System.out.println(j+" "+i+"Arc "+Math.abs((Points.get(j-1))+(initialPoint/8))+" "+Math.abs(150)+" "+Math.abs(Points.get(i-1)-Points.get(j-1))+" "+Math.abs(Points.get(i-1)-Points.get(j-1)));
                        //g2d.draw(q);
                        g.setColor(Color.red);
                        if(array[i][j].equals("-")){
                            g.drawString("-1",(((Points.get(j-1))+(initialPoint/8))+((Points.get(i-1)-Points.get(j-1)))/2) ,(150-((Points.get(i-1)-Points.get(j-1)))/8) );

                        }
                        else {
                            g.drawString(array[i][j],(((Points.get(j-1))+(initialPoint/8))+((Points.get(i-1)-Points.get(j-1)))/2) ,(150-((Points.get(i-1)-Points.get(j-1)))/8) );
                        }
                        g.setColor(Color.darkGray);
                    }
                    else{
                        g.drawArc(((Points.get(i-1))+(initialPoint/8)),(150+((Points.get(i-1)-Points.get(j-1)))/8),(Points.get(j-1)-Points.get(i-1)),(Points.get(j-1)-Points.get(i-1))/4,180,180);
                        // System.out.println(j+" "+i+"Arc "+Math.abs((Points.get(j-1))+(initialPoint/8))+" "+Math.abs(150)+" "+Math.abs(Points.get(i-1)-Points.get(j-1))+" "+Math.abs(Points.get(i-1)-Points.get(j-1)));
                        g.setColor(Color.red);
                        if(array[i][j].equals("-")){
                            g.drawString("-1",(((Points.get(j-1))+(initialPoint/8))+((Points.get(i-1)-Points.get(j-1)))/2) ,(150+((Points.get(j-1)-Points.get(i-1)))/8) );
                        }
                        else {
                            g.drawString(array[i][j],(((Points.get(j-1))+(initialPoint/8))+((Points.get(i-1)-Points.get(j-1)))/2) ,(150+((Points.get(j-1)-Points.get(i-1)))/8) );
                        }
                        g.setColor(Color.darkGray);

                    }

                }
            }
        }

//        g2d.setPaint(new Color(150, 150, 150));
//

//        g2d.fillRect(30, 20, 50, 50);
//        g2d.fillRect(120, 20, 90, 60);
//        g2d.fillRoundRect(250, 20, 70, 60, 25, 25);
//
//        g2d.fill(new Ellipse2D.Double(10, 100, 80, 100));
//        g2d.fillArc(120, 130, 110, 100, 5, 150);
//        g2d.fillOval(270, 130, 50, 50);
    }
//    public void paint(Graphics g) {
//        super.paint(g);
//

//    }//(Math.abs(Points.get(i-1)-Points.get(j-1)))/2

}
