import java.awt.*;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;

import javax.swing.JToolBar;
import javax.swing.JButton;
import javax.swing.JMenuBar;
import java.awt.event.ActionListener;
import java.awt.image.ImageObserver;
import java.util.LinkedList;
import java.awt.event.ActionEvent;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import javax.swing.event.AncestorListener;
import javax.swing.event.AncestorEvent;
import javax.swing.JDesktopPane;

public class GUIDraw {
	JDesktopPane desktop = new JDesktopPane();
	JTextArea Equations = new JTextArea();
	JTextArea NumEquation = new JTextArea();
	JTextArea NumNode = new JTextArea();
	JTextArea textArea_2 = new JTextArea();
	JTextArea textArea_3 = new JTextArea();
	JTextArea textArea_4 = new JTextArea();
	JTextArea textArea_5 = new JTextArea();
	static int  NumberNode;
	static String [][] Basic;
	InternalPage p1;

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUIDraw window = new GUIDraw();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUIDraw() {
		initialize();

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1619, 807);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setAlwaysOnTop(true);
		//frame.setResizable(false);
//		Toolkit tk=Toolkit.getDefaultToolkit();
//		int xSize=(int)tk.getScreenSize().getWidth();
//		int YSize=(int)tk.getScreenSize().getHeight();
//		frame.setSize(xSize,YSize);
		desktop.setBounds(10, 376, 1164, 394);
		frame.getContentPane().add(desktop);


		JLabel lblNewLabel = new JLabel("The Number Of Nodes :");
		lblNewLabel.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setBounds(10, 39, 246, 42);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("The Equation in Terms (x) Small :");
		lblNewLabel_1.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setBounds(10, 156, 279, 94);
		frame.getContentPane().add(lblNewLabel_1);

		JButton btnNewButton_1 = new JButton("Clear");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Equations.setText("");
				NumNode.setText("");
				NumEquation.setText("");
				textArea_5.setText("");
				textArea_3.setText("");
				textArea_2.setText("");
				textArea_4.setText("");
			}
		});
		btnNewButton_1.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_1.setBounds(711, 51, 107, 21);
		frame.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("Submit");

		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(((!Equations.getText().equals(""))&&(!NumNode.getText().equals("")))&&(!NumEquation.getText().equals(""))) {
					if((NumEquation.getText().matches("\\d+"))&&(NumNode.getText().matches("\\d+"))) {
						Parser pars=new Parser();
						String line[]=Equations.getText().split("\\n");
						NumberNode=Integer.parseInt(NumNode.getText());
						boolean flag=pars.BeSure(Integer.parseInt(NumNode.getText()),line);
						if(flag) {

							Summation sum=new Summation();
							OrganizationFormula Organize=new OrganizationFormula();
							FinalFormula Formula=new FinalFormula();
							Basic=pars.Stabn;
							LinkedList<LinkedList<String>>Forward=Organize.ForwardPath(pars.Basic);
							System.out.println("finsh follow");
							LinkedList<LinkedList<String>>Loop=Organize.LoopsPath(pars.Basic);

							LinkedList<LinkedList<Integer>>NOnTouch=sum.NonTouchingLoops(Loop);
							String BigDelta=sum.BigDelta(NOnTouch,Loop);
							LinkedList<String> SmallDelta=sum.MakeDelta(Forward,Loop);
							Formula.Expression(Forward,BigDelta,SmallDelta);
							WriteInForward(Forward);
							WriteInLoop(Loop);
							WriteInNonTouched(NOnTouch);
							WriteInTransferFunction(Formula.Output,BigDelta);
							p1=new InternalPage();//NumberNode,Basic);
							desktop.add(p1);
							p1.setVisible(true);




						}

					}
					else {
						JOptionPane.showMessageDialog(frame, "The Input Must Be Integer In the Two F.","Error", JOptionPane.ERROR_MESSAGE);
					}
				}
				else {
					JOptionPane.showMessageDialog(frame, "All Input Must Be Insert.","Error", JOptionPane.ERROR_MESSAGE);
				}

			}
		});
		btnNewButton_2.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_2.setBounds(711, 103, 107, 21);
		frame.getContentPane().add(btnNewButton_2);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 1530, 22);
		frame.getContentPane().add(menuBar);

		JMenu mnNewMenu = new JMenu("File");
		mnNewMenu.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 14));
		menuBar.add(mnNewMenu);

		JMenuItem mntmNewMenuItem = new JMenuItem("Restart");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Equations.setText("");
				NumNode.setText("");
				NumEquation.setText("");
				textArea_5.setText("");
				textArea_3.setText("");
				textArea_2.setText("");
				textArea_4.setText("");
			}
		});
		mntmNewMenuItem.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 14));
		mnNewMenu.add(mntmNewMenuItem);

		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Close");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mntmNewMenuItem_1.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 14));
		mnNewMenu.add(mntmNewMenuItem_1);

		JLabel lblTheOutput = new JLabel("The Loops :");
		lblTheOutput.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 15));
		lblTheOutput.setBounds(1116, 191, 235, 24);
		frame.getContentPane().add(lblTheOutput);

		JLabel lblTheFow = new JLabel("The Forward Path :");
		lblTheFow.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 15));
		lblTheFow.setBounds(977, 10, 279, 37);
		frame.getContentPane().add(lblTheFow);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(278, 156, 357, 187);
		frame.getContentPane().add(scrollPane);


		Equations.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 13));
		scrollPane.setViewportView(Equations);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(278, 32, 357, 52);
		frame.getContentPane().add(scrollPane_1);


		NumNode.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 13));
		scrollPane_1.setViewportView(NumNode);

		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(937, 45, 389, 136);
		frame.getContentPane().add(scrollPane_2);


		textArea_3.setEnabled(false);
		textArea_3.setEditable(false);
		textArea_3.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 13));
		scrollPane_2.setViewportView(textArea_3);

		JLabel label = new JLabel("The Output As Transfer Function :");
		label.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 15));
		label.setBounds(1185, 324, 279, 61);
		frame.getContentPane().add(label);

		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(1116, 217, 316, 126);
		frame.getContentPane().add(scrollPane_3);


		textArea_2.setEnabled(false);
		textArea_2.setEditable(false);
		textArea_2.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 13));
		scrollPane_3.setViewportView(textArea_2);

		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(723, 217, 289, 126);
		frame.getContentPane().add(scrollPane_4);
		textArea_4.setEnabled(false);
		textArea_4.setEditable(false);
		textArea_4.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 13));
		scrollPane_4.setViewportView(textArea_4);

		JLabel lblTheNonTouched = new JLabel("The Non Touched Loops :");
		lblTheNonTouched.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 15));
		lblTheNonTouched.setBounds(726, 173, 242, 61);
		frame.getContentPane().add(lblTheNonTouched);

		JScrollPane scrollPane_5 = new JScrollPane();
		scrollPane_5.setBounds(1184, 376, 342, 394);
		frame.getContentPane().add(scrollPane_5);
		scrollPane_5.setViewportView(textArea_5);


		textArea_5.setEnabled(false);
		textArea_5.setEditable(false);
		textArea_5.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 13));




		JLabel lblTeDigramOf = new JLabel("The Digram of Nodes :");
		lblTeDigramOf.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 15));
		lblTeDigramOf.setBounds(10, 328, 175, 52);
		frame.getContentPane().add(lblTeDigramOf);

		JScrollPane scrollPane_6 = new JScrollPane();
		scrollPane_6.setBounds(278, 94, 357, 52);
		frame.getContentPane().add(scrollPane_6);


		NumEquation.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 13));
		scrollPane_6.setViewportView(NumEquation);

		JLabel lblTheNumberOf = new JLabel("The Number Of Equation :");
		lblTheNumberOf.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 15));
		lblTheNumberOf.setBounds(10, 91, 246, 42);
		frame.getContentPane().add(lblTheNumberOf);

		JLabel lblTheF = new JLabel("The Lines Above The Vertex Are forward Refrence Anther Are Backword Paths ");
		lblTheF.setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 15));
		lblTheF.setBounds(278, 343, 630, 32);
		frame.getContentPane().add(lblTheF);

	}
	public void WriteInLoop(LinkedList<LinkedList<String>>Loop) {
		for(int i=0;i<Loop.size();i++) {
			textArea_2.append("L"+i+"="+Loop.get(i).get(1)+"\n");
			textArea_2.append("The Path Of L"+i+"="+Loop.get(i).get(0)+"\n");
		}
	}
	public void WriteInForward(LinkedList<LinkedList<String>>Forward) {
		for(int i=0;i<Forward.size();i++) {
			textArea_3.append("P"+i+"="+Forward.get(i).get(1)+"\n");
			textArea_3.append("The Path Of P"+i+"="+Forward.get(i).get(0)+"\n");
		}
	}
	//
	public void WriteInNonTouched(LinkedList<LinkedList<Integer>>NOnTouch) {
		for(int i=0;i<NOnTouch.size();i++) {
			textArea_4.append("L"+(NOnTouch.get(i).get(0))+" & "+"L"+(NOnTouch.get(i).get(1))+"\n");

		}
	}
	public void WriteInTransferFunction(String Output,String BigDelta) {
		textArea_5.append("         "+Output+"\n");
		textArea_5.append("T.F "+"= ");
		for(int i=0;i<BigDelta.length();i++){
			textArea_5.append("_");
		}
		textArea_5.append("\n");
		textArea_5.append("         "+BigDelta);
	}
}
