import java.util.LinkedList;

public class FinalFormula {
    String Output="";
    public void Expression(LinkedList<LinkedList<String>>Forward,String BigDelta,LinkedList<String> SmallDelta){
        //String Output="";

        boolean flag=false;
        for(int i=0;i<Forward.size();i++){
            if(flag==true){
                Output+="+";
            }
            Output+="("+SmallDelta.get(i)+")"+"("+Forward.get(i).get(1)+")";
            flag=true;
        }
        System.out.println(Output);
        System.out.println("__________________");
        System.out.println(BigDelta);
    }
}
