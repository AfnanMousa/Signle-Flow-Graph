import java.awt.Point;
import java.util.*;

public class OrganizationFormula {

    private LinkedList<LinkedList<Integer>>StoreLoops=new LinkedList<LinkedList<Integer>>();
    private LinkedList<LinkedList<String>>ForwardPaths=new LinkedList<LinkedList<String>>();
    private LinkedList<LinkedList<String>>LoopPaths=new LinkedList<LinkedList<String>>();

    public LinkedList<LinkedList<String>> ForwardPath(String[][] Base){
        String Path="";
        String Values="";
        LinkedList<LinkedList<Integer>>Store=new LinkedList<LinkedList<Integer>>();
        for(int j=1;j<Base.length;j++){
            LinkedList<Integer> tempPath=new LinkedList<Integer>();
            for(int i=1;i<Base.length;i++){
                if(Base[i][j]!=null){
                    tempPath.add(i);
                }
            }
            Store.add(tempPath);
        }
        //Map<Integer,String> map=new HashMap<Integer,String>();
        Stack<Point> help= new Stack<Point>();
        Map<Point,String> map=new HashMap<Point,String>();
        Map<Point,String> mapValues=new HashMap<Point,String>();
        int x=0;
        while ((x==0)||(help.size()!=0)){
            for(int i=0;i<Store.size();){
                if((Store.get(i).size()==1)){
                    if((check(Path,""+Store.get(i).get(0)))){
                        Path+="x"+(i+1);
                        if((Base[Store.get(i).get(0)][i+1].equals("-"))||(Base[Store.get(i).get(0)][i+1].equals("-1"))){
                            Values="-"+Values;
                        }
                        else if(!Base[Store.get(i).get(0)][i+1].equals("1")){
                            Values+=Base[Store.get(i).get(0)][i+1]+"*";
                        }
                        i=Store.get(i).get(0)-1;
                    }
                    else {
                        if(Path.charAt(Path.length()-1)==Base.length-1){
                            LinkedList<String>Channel=new LinkedList<>();
                            Channel.add(Path);
                            if(Values.charAt(Values.length()-1)=='*'){
                                Values=Values.substring(0,Values.length()-1);
                            }
                            Channel.add(Values);
                            ForwardPaths.add(Channel);
                            System.out.println(Path);
                            System.out.println(Values);
                            Path="";
                            Values="";

                        }
                        if(!help.empty()){
                            Point temp=new Point();
                            temp=help.pop();
                            int y= temp.x;
                            i=y;
                            Path=map.get(temp);
                            int t=Integer.parseInt(Path.charAt(Path.length()-1)+"");
                            if((Base[y][t].equals("-"))||(Base[y][t].equals("-1"))){
                                Values="-"+Values;
                            }
                            else if(!Base[y][t].equals("1")){
                                Values=mapValues.get(temp)+Base[y][t]+"*";
                            }
                            else {
                                Values=mapValues.get(temp);
                            }
                            i-=1;
                            x=1;
                        }
                        else {
                            break;
                        }
                    }
                }
                else if(Store.get(i).size()>1){
                    Path+="x"+(i+1);
                    int flag=0;
                    if((Path.length()>0)&&(Integer.parseInt(Path.charAt(Path.length()-1)+"")==(Base.length-1))){//(""+Path.charAt(1)).equals(i)
                        LinkedList<String>Channel=new LinkedList<>();
                        Channel.add(Path);
                        if(Values.charAt(Values.length()-1)=='*'){
                            Values=Values.substring(0,Values.length()-1);
                        }
                        Channel.add(Values);
                        ForwardPaths.add(Channel);
                        System.out.println(Path);
                        System.out.println(Values);
                        Path="";
                        Values="";
                        if(!help.empty()){
                            Point u=help.pop();
                            int y=u.x;
                            i=y;
                            Path=map.get(u);
                            int o=Integer.parseInt(""+Path.charAt(Path.length()-1));
                            if((Base[y][o].equals("-"))||(Base[y][o].equals("-1"))){
                                Values="-"+Values;
                            }
                            else if(!Base[y][o].equals("1")){
                                Values=mapValues.get(u)+Base[y][o]+"*";
                            }
                            i--;
                        }
                        else {
                            break;
                        }
                    }
                    else {
                        for(int j=Store.get(i).size()-1;j>=0;j--){
                            if(check(Path,""+Store.get(i).get(j))){
                                Point temp1=new Point();
                                temp1.x=Store.get(i).get(j);
                                temp1.y=(i+1);
                                map.put(temp1,Path);
                                mapValues.put(temp1,Values);
                                help.push( temp1);
                                flag=1;
                            }
                        }
                        if(flag==0){
                            LinkedList<String>Channel=new LinkedList<>();
                            Channel.add(Path);
                            if(Values.charAt(Values.length()-1)=='*'){
                                Values=Values.substring(0,Values.length()-1);
                            }
                            Channel.add(Values);
                            ForwardPaths.add(Channel);
                            System.out.println(Path);
                            System.out.println(Values);
                            Path="";
                            Values="";
                        }

                        if(!help.empty()){
                            Point u=help.pop();
                            int y=u.x;
                            i=y;
                            Path=map.get(u);
                            int o=Integer.parseInt(""+Path.charAt(Path.length()-1));
                            if((Base[y][o].equals("-"))||(Base[y][o].equals("-1"))){
                                Values="-"+Values;
                            }
                            else if(!Base[y][o].equals("1")){
                                Values=mapValues.get(u)+Base[y][o]+"*";
                            }
                        }

                        i-=1;
                        x=1;
                    }

                }
                else if(Store.get(i).size()==0){
                    Path+="x"+(i+1);
                    LinkedList<String>Channel=new LinkedList<>();
                    Channel.add(Path);
                    if(Values.charAt(Values.length()-1)=='*'){
                        Values=Values.substring(0,Values.length()-1);
                    }
                    Channel.add(Values);
                    ForwardPaths.add(Channel);
                    System.out.println(Path);
                    System.out.println(Values);
                    Path="";
                    Values="";
                    if(!help.empty()){
                        //int s=i+1;
                        Point p=help.pop();
                        int y= p.x;
                        i=y;
                        Path=map.get(p);
                        int u=Integer.parseInt(Path.charAt(Path.length()-1)+"");
                        if((Base[y][u].equals("-"))||(Base[y][u].equals("-1"))){
                            Values="-"+Values;
                        }
                        else if(!Base[y][u].equals("1")){
                            Values=mapValues.get(p)+Base[y][u]+"*";
                        }
                        else {
                            Values=mapValues.get(p);
                        }
                        i-=1;
                        x=1;
                    }
                    else {
                        break;
                    }
                }
            }
        }
        return ForwardPaths;
    }




    public LinkedList<LinkedList<String>> LoopsPath(String[][]Base){
        String Path="";
        String Values="";
        LinkedList<LinkedList<Integer>>Store=new LinkedList<LinkedList<Integer>>();
        for(int j=1;j<Base.length;j++){
            LinkedList<Integer> tempPath=new LinkedList<Integer>();
            for(int i=Base.length-1;i>1;i--){
                if(Base[i][j]!=null){
                    tempPath.add(i);
                }
            }
            Store.add(tempPath);
        }
        for(int i=1;i<Base.length;i++){
            LinkedList<Integer> tempPath=new LinkedList<Integer>();
            for(int j=1;j<Base.length;j++){
                if(Base[i][j]!=null){
                    tempPath.add(j);
                }

            }
            StoreLoops.add(tempPath);
        }


        for (int z=1;z<StoreLoops.size();z++){
            int x=0;
            Path="";
            Values="";
            Stack<Point> help= new Stack<Point>();
            Map<Point,String> map=new HashMap<Point,String>();
            Map<Point,String> mapValues=new HashMap<Point,String>();
            boolean flag3=false;
            int temp=z;
            while ((x==0)||(help.size()!=0)) {
                for (int i = z-1; i < Store.size(); ) {
                    if (Store.get(i).size() == 1) {
                        if(Store.get(i).get(0)!=z+1){
                            if(check(Path, ""+(Store.get(i).get(0)))) {
                                Path += "x" + (Store.get(i).get(0));

                                if((Base[Store.get(i).get(0)][i + 1] .equals("-") )||(Base[Store.get(i).get(0)][i + 1].equals("-1"))){
                                    Values="-"+Values;
                                }
                                else if (!Base[Store.get(i).get(0)][i + 1] .equals("1") ) {
                                    Values += Base[Store.get(i).get(0)][i + 1]+"*";
                                }
                                i=Store.get(i).get(0)-1;
                                flag3=true;
                            }
                            else {
                                if(Integer.parseInt(Path.charAt(1)+"")==(Store.get(i).get(0))) {
                                    String pass=Values;
                                    if((Base[Store.get(i).get(0)][i + 1] .equals("-") )||(Base[Store.get(i).get(0)][i + 1].equals("-1"))){
                                        pass="-"+Values;
                                    }
                                    else if (!Base[Store.get(i).get(0)][i + 1] .equals("1") ) {
                                        pass =Values+ Base[Store.get(i).get(0)][i + 1];
                                        if(pass.charAt(pass.length()-1)=='*'){
                                            pass=pass.substring(0,pass.length()-1);
                                        }
                                    }
                                    LinkedList<String>Channel=new LinkedList<>();
                                    Channel.add(Path+"x"+Store.get(i).get(0));
                                    Channel.add(pass);
                                    LoopPaths.add(Channel);
                                    System.out.println(Path+"x"+Store.get(i).get(0));
                                    System.out.println(pass);
                                    if(!help.empty()){
                                        Point c=help.pop();
                                        Path=map.get(c)+"x"+c.x;
                                        if((Base[c.x][c.y] .equals("-") )||(Base[c.x][c.y].equals("-1"))){
                                            Values="-"+mapValues.get(c);
                                        }
                                        else if (!Base[c.x][c.y] .equals("1") ) {
                                            Values =mapValues.get(c)+ Base[c.x][c.y]+"*";
                                        }
                                        i=(c.x)-1;
                                    }
                                    else {
                                        x=1;
                                        break;
                                    }

                                }
                                if(!help.empty()) {
                                    Point p =new Point();
                                    p= help.pop();
                                    String pass = map.get(p);
                                    while((!help.empty())&&(!check(pass, ""+p.x))) {
                                        p=help.pop();
                                        pass=map.get(p);
                                    }

                                    if((map.get(p).equals(""))&&(mapValues.get(p).equals(""))){
                                        Values="";
                                    }
                                    else if((Base[p.x][p.y] .equals("-") )||(Base[p.x][p.y].equals("-1"))){
                                        Values="-"+mapValues.get(p);
                                    }
                                    else if (!Base[p.x][p.y] .equals("1") ) {
                                        Values =mapValues.get(p)+ Base[p.x][p.y]+"*";
                                    }
                                    Path = map.get(p)+"x"+p.x;
                                    i=(p.x)-1;
                                }
                                else{
                                    x=1;
                                    break;
                                }


                            }

                        }
                        else {
                            if(check(Path, ""+(Store.get(i).get(0)))) {
                                Path += "x" + (Store.get(i).get(0));
                                i++;
                                flag3=true;
                            }
                            else {
                                if(Integer.parseInt(Path.charAt(1)+"")==(Store.get(i).get(0))) {

                                    String pass=Values;
                                    if((Base[Store.get(i).get(0)][i + 1] .equals("-") )||(Base[Store.get(i).get(0)][i + 1].equals("-1"))){
                                        pass="-"+Values;
                                        if(pass.charAt(pass.length()-1)=='*'){
                                            pass=pass.substring(0,pass.length()-1);
                                        }
                                    }
                                    else if (!Base[Store.get(i).get(0)][i + 1] .equals("1") ) {
                                        pass =Values+ Base[Store.get(i).get(0)][i + 1];
                                    }
                                    LinkedList<String>Channel=new LinkedList<>();
                                    Channel.add(Path+"x"+Store.get(i).get(0));
                                    Channel.add(pass);
                                    LoopPaths.add(Channel);
                                    System.out.println(Path+"x"+Store.get(i).get(0));
                                    System.out.println(pass);
                                    if(!help.empty()){
                                        Point c=help.pop();
                                        Path=map.get(c)+"x"+c.x;
                                        if((Base[c.x][c.y] .equals("-") )||(Base[c.x][c.y].equals("-1"))){
                                            Values="-"+mapValues.get(c);
                                        }
                                        else if (!Base[c.x][c.y] .equals("1") ) {
                                            Values =mapValues.get(c)+ Base[c.x][c.y]+"*";
                                        }
                                        i=(c.x)-1;
                                    }
                                    else {
                                        x=1;
                                        break;
                                    }

                                }
                            }

                        }
                    }
                    else if (Store.get(i).size() > 1) {

                        boolean flag4=false;
                        String RemovePath=Path;
                        String RemoveValue=Values;
                        boolean flag2=false;
                        for (int j = 0; j < Store.get(i).size(); j++) {
                            boolean flag5=false;
                            if((i+1!=z)&&(Integer.parseInt(Path.charAt(1)+"")==(Store.get(i).get(j)))) {//i + 1 == Store.size()//(Store.get(i).get(j).equals(temp+1))
                                Path +="x"+Store.get(i).get(j);//(z+1);

                                if((Base[Store.get(i).get(j)][i+1].equals("-"))||(Base[Store.get(i).get(j)][i+1].equals("-1"))){
                                    Values="-"+Values;
                                    if(Values.charAt(Values.length()-1)=='*'){
                                        Values=Values.substring(0,Values.length()-1);
                                    }
                                }
                                else if (!Base[Store.get(i).get(j)][i+1].equals("1") ) {
                                    Values += Base[Store.get(i).get(j)][i+1];
                                }
                                LinkedList<String>Channel=new LinkedList<>();
                                Channel.add(Path);
                                Channel.add(Values);
                                LoopPaths.add(Channel);
                                System.out.println(Path);
                                System.out.println(Values);
                                flag2=true;
                                flag5=true;
                            }
                            if(((flag2==true)&&(flag5==true))&&(j+1>=Store.get(i).size())) {
                                Path = "";
                                Values = "";
                            }
                            else if((flag2==true)&&(flag5==false)) {
                                Point p =new Point();
                                p.x=Store.get(i).get(j);
                                p.y=i+1;
                                if(check(Path,""+p.x)) {
                                    map.put(p, RemovePath);
                                    mapValues.put(p, RemoveValue);
                                    help.push(p);
                                    flag4=true;
                                }
                            }
                            else if((flag5==false)&&(flag2==false)){
                                Point p =new Point();
                                p.x=Store.get(i).get(j);
                                p.y=i+1;
                                if(check(Path,""+p.x)) {
                                    map.put(p, Path);
                                    mapValues.put(p, Values);
                                    help.push(p);
                                }
                            }

                        }
                        if(flag4==true) {
                            Path=RemovePath;
                            Values=RemoveValue;
                        }

                        if(!help.empty()){
                            Point p=help.pop();
                            // int y = help.pop();
                            int y=p.x;
                            if(i+1==z) {
                                temp=y-1;
                            }

                            if(check(Path,"x"+y)) {
                                int s;
                                if(map.get(p).length()!=0){
                                    s=Integer.parseInt(""+map.get(p).charAt(map.get(p).length()-1));
                                    Path = map.get(p)+"x"+y;
                                    if((Base[y][s]!=null)&&((Base[y][s].equals("-"))||(Base[y][s].equals("-1")))){
                                        Values="-"+mapValues.get(p) ;
                                    }
                                    else if ((Base[y][s]!=null)&&(!Base[y][s] .equals("1") )) {
                                        Values = mapValues.get(p) + Base[y][s]+"*";
                                    }
                                }
                                else {
                                    //s=z;
                                    Path = map.get(p)+"x"+y;
                                    Values="";
                                }

                                i = y-1;
                                x = 1;
                            }
                            else {
                                p=help.pop();
                                //y = help.pop();
                                y=p.x;
                                while((!help.empty())&&(!check(Path,"x"+y))) {
                                    p= help.pop();
                                    y=p.x;
                                }
                                i=y-1;
                            }
                        }
                        else {
                            break;
                        }
                    }
                    else if (Store.get(i).size()==0){
                        x=1;
                        Point c=new Point();
                        if(!help.empty()){
                            c=help.pop();
                            Path=map.get(c)+"x"+c.x;
                            if((Base[c.x][c.y] .equals("-") )||(Base[c.x][c.y].equals("-1"))){
                                Values="-"+mapValues.get(c);
                            }
                            else if (!Base[c.x][c.y] .equals("1") ) {
                                Values =mapValues.get(c)+ Base[c.x][c.y]+"*";
                            }
                            i=(c.x-1);
                            x=0;
                        }
                        else {
                            break;
                        }
                    }
                }
            }


            for(int r=1;r<Base.length;r++) {
                Base[temp+1][r]=null;
            }
            LinkedList<Integer> t=new LinkedList<>();
            Map<Integer,Integer> d=new HashMap<Integer,Integer>();
            d.put(temp+1,temp+1);
            t.add(temp);
            for(int e=0;e<Store.size();e++) {
                for (int w = Store.get(e).size()-1; w >= 0; w--) {
                    if ((Store.get(e).size()!=0)&&(d.containsKey(Store.get(e).get(w)))) {
                        Store.get(e).remove(w);
                        // t.add(temp);
                        if ((e + 1) == temp) {
                            for (int u = 0;( (u>-1)&&(u < Store.get(e).size()));) {
                                t.add(Store.get(e).get(u)-1);
                                d.put(Store.get(e).get(u),Store.get(e).get(u));
                                Store.get(e).remove(u);
                                u=0;
                            }
                        }
                    }
                }
            }
            for(int e=0;e<t.size();e++){
                if((StoreLoops.get(t.get(e)).size()!=0)){
                    for(int u=0;((u>-1)&&(u<StoreLoops.get(t.get(e)).size()));){
                        StoreLoops.get(t.get(e)).remove(u);
                        u=0;
                    }
                }
            }


        }
        System.out.println("finish loop");
        return LoopPaths;
    }
    private boolean check(String path,String symbol) {
        if(path.contains(symbol)) {
            return false;
        }
        else {
            return true;
        }
    }

}

