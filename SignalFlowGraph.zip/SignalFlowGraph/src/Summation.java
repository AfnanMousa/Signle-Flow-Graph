import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;

public class Summation {


   // int count=0;
    public LinkedList<LinkedList<Integer>> NonTouchingLoops(LinkedList<LinkedList<String>> LoopPaths){
        LinkedList<LinkedList<Integer>>NonTouchNode=new LinkedList<LinkedList<Integer>>();
        for(int i=0;i<LoopPaths.size();i++){
            String temp1=LoopPaths.get(i).get(0);
            temp1=temp1.replaceAll("x","");
            for(int j=i+1;j<LoopPaths.size();j++){
                String temp2=LoopPaths.get(j).get(0);
                temp2=temp2.replaceAll("x","");
                String Common=findCommonChars(temp1,temp2);
                if(Common.equals("")){
                   // count++;
                    LinkedList<Integer> Channel=new LinkedList<>();
                    Channel.add(i);
                    Channel.add(j);
                    NonTouchNode.add(Channel);
//                    System.out.println((i+1)+" "+(j+1));
                }
            }

        }
        return NonTouchNode;
    }
    public String BigDelta(LinkedList<LinkedList<Integer>>NonTouchNode,LinkedList<LinkedList<String>>LoopsPath){
        String Delta="1";
        String Sum="";
        boolean flag=false;
          for(int i=0;i<LoopsPath.size();i++){
              if(flag==true){
                  Sum+="+";
              }
              Sum+="("+LoopsPath.get(i).get(1)+")";
              flag=true;
          }
          if(!Sum.equals("")){
              Delta+="-"+"("+Sum+")";
          }
        Sum="";
          flag=false;
          for(int i=0;i<NonTouchNode.size();i++){
              if(flag==true){
                  Sum+="+";
              }
              Sum+="L"+NonTouchNode.get(i).get(0)+"L"+NonTouchNode.get(i).get(1);
              flag=true;
          }
          if(!Sum.equals("")){
              Delta+="+"+"("+Sum+")";
          }
        return Delta;
    }
    public LinkedList<String> MakeDelta(LinkedList<LinkedList<String>>ForwardPaths,LinkedList<LinkedList<String>>LoopPaths){

        //int counter=0;
        LinkedList<String>SmallDelta=new LinkedList<String>();
        for (int i=0;i<ForwardPaths.size();i++){
            String Sum="";
            int counter=0;
            String delta="";
            String temp1=ForwardPaths.get(i).get(0);
            temp1=temp1.replaceAll("x","");
            boolean flag=false;
            LinkedList<LinkedList<String>>loop=new LinkedList<LinkedList<String>>();
            for(int j=0;j<LoopPaths.size();j++){
                String temp2=LoopPaths.get(j).get(0);
                temp2=temp2.replaceAll("x","");
                String Common=findCommonChars(temp1,temp2);
                if(Common.equals("")){
                    if(flag==true){
                        Sum+="+";
                    }
                    Sum+=LoopPaths.get(j).get(1);
                    counter++;
                    LinkedList<String>spam=new LinkedList();
                    spam.add(LoopPaths.get(j).get(0));
                    spam.add(LoopPaths.get(j).get(1));
                    loop.add(spam);
                    flag=true;
                }
            }
            if(counter==1){
                if(!Sum.equals("")){
                    delta+="1"+"-"+"("+Sum+")";
                }
                else {
                    delta+="1";

                }
                SmallDelta.add(delta);
            }

            else if(counter>1){
                String ValueOfNonTouching="";
                boolean flag1=true;
                delta+="1"+"-"+"("+Sum+")";
                LinkedList<LinkedList<Integer>>NonTouchNode=NonTouchingLoops(loop);
                for(int z=0;z<NonTouchNode.size();z++){
                    if(flag1==false){
                        ValueOfNonTouching+="+";
                    }
                    ValueOfNonTouching+="L"+NonTouchNode.get(z).get(0)+"L"+NonTouchNode.get(z).get(1);
                    flag1=false;
                }
                delta+="+"+"("+ValueOfNonTouching+")";
                SmallDelta.add(delta);
            }
            else {
                delta+="1";
                SmallDelta.add(delta);
            }
        }
        return SmallDelta;
    }

    static String findCommonChars(String a, String b) {
        StringBuilder resultBuilder = new StringBuilder();
        Set<Character> charsMap = new HashSet<Character>();
        for (int i = 0; i < a.length(); i++) {
            char ch = a.charAt(i); //a and b are the two words given by the user
            if (b.indexOf(ch) != -1){
                charsMap.add(Character.valueOf(ch));
            }
        }

        Iterator<Character> charsIterator = charsMap.iterator();
        while(charsIterator.hasNext()) {
            resultBuilder.append(charsIterator.next().charValue());
        }
        return resultBuilder.toString();
    }
}
