import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Try {
    public static void main(String args[]) {
        Scanner scan =new Scanner(System.in);
        int NumberOfNode=scan.nextInt();
        int NumberOfEquations=scan.nextInt();
        String[] Equations = new String[NumberOfEquations+1];
        for(int i=0;i<=NumberOfEquations;i++){
            Equations[i]=scan.nextLine();
        }
        Parser pars=new Parser();
        pars.BeSure(NumberOfNode,Equations);
    }
}
