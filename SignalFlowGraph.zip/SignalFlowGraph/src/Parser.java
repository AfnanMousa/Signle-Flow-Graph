import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Parser {
	static String [][] Basic;
    static String [][] Stabn;
    public static boolean BeSure(int NumberOfNode,String[] Equations){
          Basic=new String[NumberOfNode+1][NumberOfNode+1];
        Stabn=new String[NumberOfNode+1][NumberOfNode+1];
        boolean flag=true;
        if(Equations.length==0){
            flag=false;
            JFrame frame=new JFrame();
            JOptionPane.showMessageDialog(frame, "There is no equation..","Error", JOptionPane.ERROR_MESSAGE);
            System.out.println("There is no equation..");
        }
        String regexEquation ="^x\\d\\D*[=]((([-])?(\\d)?(\\D*(\\d)?\\D*([+-/*])?)*x\\d[+])*)?([-])?(\\d)?(\\D*(\\d)?\\D*([+-/*])?)*x\\d";
        Pattern pattern = Pattern.compile(regexEquation);
        LinkedList<Integer> storeLine=new LinkedList<Integer>();
       // LinkedList<Integer> Partation=new LinkedList<Integer>();
         for(int i=0;i<Equations.length;i++){
             Equations[i]=Equations[i].replaceAll("\\s+","");
             Matcher matcher = pattern.matcher(Equations[i]);
             LinkedList<Integer> Partation=new LinkedList<Integer>();
             if(matcher.matches()){
                 String []temp=Equations[i].split("=");
                 String []SplitByDigit=temp[0].split("[^a-z0-9]+|(?<=[a-z])(?=[0-9])|(?<=[0-9])(?=[a-z])");
                 if(!storeLine.contains(Integer.parseInt(SplitByDigit[1]))) {
                     storeLine.add(Integer.parseInt(SplitByDigit[1]));
                     String value="";
                     for(int j=0;j<temp[1].length();j++){
                           if(temp[1].charAt(j)=='x'){
                               if((j+1<temp[1].length())&&(Integer.parseInt(""+temp[1].charAt(j+1))<=NumberOfNode)){
                                   if(!Partation.contains(Integer.parseInt(""+temp[1].charAt(j+1)))){
                                       if(value==""){
                                           Basic[Integer.parseInt(SplitByDigit[1])][Integer.parseInt(""+temp[1].charAt(j+1))]="1";
                                           Stabn[Integer.parseInt(SplitByDigit[1])][Integer.parseInt(""+temp[1].charAt(j+1))]="1";
                                       }
                                       else {
                                           Basic[Integer.parseInt(SplitByDigit[1])][Integer.parseInt(""+temp[1].charAt(j+1))]=value;
                                           Stabn[Integer.parseInt(SplitByDigit[1])][Integer.parseInt(""+temp[1].charAt(j+1))]=value;
                                       }
                                       value="";
                                       Partation.add(Integer.parseInt(""+temp[1].charAt(j+1)));
                                       if((j+2<temp[1].length())&&(temp[1].charAt(j+2)=='+')){
                                           j=j+2;
                                       }
                                       else{
                                           j=j+1;
                                       }
                                   }
                                   else {
                                       flag=false;
                                       System.out.println("Error in the syntax of the Equation which order is "+i);
                                       JFrame frame=new JFrame();
                                       JOptionPane.showMessageDialog(frame, "Error in the syntax of the Equation which order is "+i,"Error", JOptionPane.ERROR_MESSAGE);
                                   }
                               }
                               else {
                                   flag=false;
                                   JFrame frame=new JFrame();
                                   JOptionPane.showMessageDialog(frame, "Error in the syntax of the Equation which order is "+i+" the equation contain number of node don't fond ","Error", JOptionPane.ERROR_MESSAGE);
                                   System.out.println("Error in the syntax of the Equation which order is "+i+" the equation contain number of node don't fond ");
                               }
                           }
                           else{
                               value+=temp[1].charAt(j);
                           }
                     }
                 }


             }
             else{
                 flag=false;
                 JFrame frame=new JFrame();
                 JOptionPane.showMessageDialog(frame, "FAIL, Incorrect input","Error", JOptionPane.ERROR_MESSAGE);
                 System.out.println("FAIL, Incorrect input");
             }
         }
         if(flag==true){
//             Summation sum=new Summation();
//             OrganizationFormula Organize=new OrganizationFormula();
//             FinalFormula Formula=new FinalFormula();
//             LinkedList<LinkedList<String>>Forward=Organize.ForwardPath(Basic);
//             LinkedList<LinkedList<String>>Loop=Organize.LoopsPath(Basic);
//             LinkedList<LinkedList<Integer>>NOnTouch=sum.NonTouchingLoops(Loop);
//             String BigDelta=sum.BigDelta(NOnTouch,Loop);
//             LinkedList<String> SmallDelta=sum.MakeDelta(Forward,Loop);
//             Formula.Expression(Forward,BigDelta,SmallDelta);
             return true;
         }
         else {
        	 return false; 
         }

    }
}
