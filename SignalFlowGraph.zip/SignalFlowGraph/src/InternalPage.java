import java.awt.*;

import javax.swing.JInternalFrame;

public class InternalPage extends JInternalFrame {
	int NumNode;
	String[][]Basic;
	Draw we;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InternalPage frame = new InternalPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */

	public InternalPage() {
		setResizable(false);
		setClosable(false);
		setTitle("Signal Flow Graph Digram");
		getContentPane().setFont(new Font("Bookman Old Style", Font.BOLD | Font.ITALIC, 14));
		setBounds(0, 0, 1164, 394);
		we=new Draw();
		add(we);
		we.setVisible(true);
//		this.NumNode=GUIDraw.NumberNode;
//		this.Basic=GUIDraw.Basic;

	}
//	public void paint(Graphics g) {
//		//super.paint(g);
//		int initialPoint=914/NumNode;
//		for(int i=0;i<NumNode;i++){
//			g.setColor(Color.darkGray);
//			g.fillOval(50,480,30,30);
//		}
//		//draw();
//	}

}



//import javax.swing.*;
//import java.awt.*;
//import java.util.HashSet;
//
//public class Graph extends JFrame {

//	/**
//	 * Create the panel.
//	 */
//	public Graph() {
//		setBackground(Color.PINK);
//		setForeground(Color.BLACK);
//		setSize( 914, 319);
//		setLayout(null);

//	}
//
//

//
//}
